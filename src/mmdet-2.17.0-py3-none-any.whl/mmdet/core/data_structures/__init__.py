# Copyright (c) OpenMMLab. All rights reserved.
from .general_data import GeneralData
from .instance_data import InstanceData

__all__ = ['GeneralData', 'InstanceData']
