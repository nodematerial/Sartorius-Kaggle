# Copyright (c) OpenMMLab. All rights reserved.
from .res_layer import ResLayer

__all__ = ['ResLayer']
