# Copyright (c) OpenMMLab. All rights reserved.
from .dropblock import DropBlock

__all__ = ['DropBlock']
